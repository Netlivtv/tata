# tata-sky-m3u-dynamic
This repo contains code to dynamically generate Tata Sky m3u playlist on request basis with a fresh JWT. In simple words, this eliminates the hassle to generate playlist after every 24 hours.

This is meant to be deployed as a serverless function on a platform like Vercel.
